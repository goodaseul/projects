/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        "./src/**/*.{js,jsx,ts,tsx}", // Tailwind가 감지할 파일 범위
    ],
    theme: {
        extend: {},
    },
    plugins: [],
};
